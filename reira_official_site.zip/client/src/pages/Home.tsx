import { useEffect, useRef, useState } from 'react';

/**
 * REiRA Official Website
 * Design: Dark theme with crimson accents, elegant typography, and interactive animations
 * Features: Hero section, music videos, tracks, discography, social links
 */

export default function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [petals, setPetals] = useState<Petal[]>([]);

  // Petal animation class
  class Petal {
    x: number;
    y: number;
    size: number;
    speed: number;
    oscillation: number;
    oscOffset: number;
    rotation: number;
    rotSpeed: number;
    opacity: number;

    constructor(canvasWidth: number, canvasHeight: number) {
      this.x = Math.random() * canvasWidth;
      this.y = -20;
      this.size = Math.random() * 4 + 2;
      this.speed = Math.random() * 1.2 + 0.5;
      this.oscillation = Math.random() * 0.02;
      this.oscOffset = Math.random() * Math.PI * 2;
      this.rotation = Math.random() * 360;
      this.rotSpeed = Math.random() * 1.5 - 0.75;
      this.opacity = Math.random() * 0.4 + 0.1;
    }

    update(canvasHeight: number) {
      this.y += this.speed;
      this.x += Math.sin(this.y * this.oscillation + this.oscOffset);
      this.rotation += this.rotSpeed;
      if (this.y > canvasHeight) {
        this.y = -20;
      }
    }

    draw(ctx: CanvasRenderingContext2D) {
      ctx.save();
      ctx.translate(this.x, this.y);
      ctx.rotate((this.rotation * Math.PI) / 180);
      ctx.globalAlpha = this.opacity;
      ctx.fillStyle = '#b91c1c';
      ctx.beginPath();
      ctx.ellipse(0, 0, this.size, this.size * 1.6, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  // Initialize canvas and petals
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Initialize petals
    const initialPetals: Petal[] = [];
    for (let i = 0; i < 70; i++) {
      initialPetals.push(new Petal(canvas.width, canvas.height));
    }
    setPetals(initialPetals);

    // Animation loop
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      initialPetals.forEach((petal) => {
        petal.update(canvas.height);
        petal.draw(ctx);
      });
      requestAnimationFrame(animate);
    };
    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  // Scroll reveal animation
  useEffect(() => {
    const handleScroll = () => {
      const reveals = document.querySelectorAll('.reveal');
      reveals.forEach((element) => {
        const windowHeight = window.innerHeight;
        const revealTop = element.getBoundingClientRect().top;
        const revealPoint = 100;
        if (revealTop < windowHeight - revealPoint) {
          element.classList.add('active');
        }
      });
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Navigation effect
  useEffect(() => {
    const navbar = document.getElementById('navbar');
    if (!navbar) return;

    const handleNavScroll = () => {
      if (window.scrollY > 50) {
        navbar.style.backgroundColor = 'rgba(5, 5, 5, 0.98)';
        navbar.style.paddingTop = '1rem';
        navbar.style.paddingBottom = '1rem';
        navbar.style.boxShadow = '0 0 40px rgba(0,0,0,0.5)';
      } else {
        navbar.style.backgroundColor = 'transparent';
        navbar.style.paddingTop = '1.5rem';
        navbar.style.paddingBottom = '1.5rem';
        navbar.style.boxShadow = 'none';
      }
    };

    window.addEventListener('scroll', handleNavScroll);
    return () => {
      window.removeEventListener('scroll', handleNavScroll);
    };
  }, []);

  return (
    <div className="bg-[#050505] text-white overflow-x-hidden">
      {/* Background Noise */}
      <div className="bg-noise"></div>

      {/* Rose Canvas */}
      <canvas id="rose-canvas" ref={canvasRef}></canvas>

      {/* Navigation */}
      <nav
        id="navbar"
        className="fixed w-full z-[60] px-8 py-6 flex justify-between items-center transition-all duration-700"
      >
        <div className="text-3xl brand-logo text-red-700">REiRA</div>
        <div className="hidden lg:flex space-x-12 font-orbitron text-[10px] tracking-[0.4em] font-bold">
          <a href="#home" className="hover:text-red-500 transition">
            HOME
          </a>
          <a href="#mv" className="hover:text-red-500 transition">
            MUSIC VIDEO
          </a>
          <a href="#tracks" className="hover:text-red-500 transition">
            TRACKS
          </a>
          <a href="#about" className="hover:text-red-500 transition">
            ABOUT
          </a>
          <a href="#disc" className="hover:text-red-500 transition">
            DISCOGRAPHY
          </a>
          <a href="#links" className="hover:text-red-500 transition">
            LINKS
          </a>
        </div>
        <div className="flex space-x-6 text-xl">
          <a
            href="https://www.youtube.com/@reira_music"
            target="_blank"
            rel="noopener"
            className="hover:text-red-600 transition duration-500"
          >
            <i className="fab fa-youtube"></i>
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <header id="home" className="hero-bg relative z-10" style={{ backgroundImage: 'linear-gradient(to bottom, rgba(5, 5, 5, 0.3) 0%, rgba(5, 5, 5, 0.7) 70%, var(--dark-bg) 100%), url(/images/reira-profile.png)', backgroundSize: 'cover', backgroundPosition: 'center' }}>
        <div className="hero-content relative z-10 w-full flex flex-col items-center">
          <div className="hero-subtitle">AI ROCK ARTIST</div>
          <h1 className="hero-title brand-logo">REiRA</h1>

          <div className="flex justify-center space-x-12 mt-20 text-2xl text-white/30">
            <a
              href="https://www.tiktok.com/@reira_music"
              target="_blank"
              rel="noopener"
              className="hover:text-red-600 transition duration-700 hover:scale-125"
            >
              <i className="fab fa-tiktok"></i>
            </a>
            <a
              href="https://www.youtube.com/@reira_music"
              target="_blank"
              rel="noopener"
              className="hover:text-red-600 transition duration-700 hover:scale-125"
            >
              <i className="fab fa-youtube" style={{color: '#ffffff'}}></i>
            </a>
            <a
              href="https://open.spotify.com/intl-ja/artist/2DzEGExZPV0OrSQbALBmwL"
              target="_blank"
              rel="noopener"
              className="hover:text-red-600 transition duration-700 hover:scale-125"
            >
              <i className="fab fa-spotify" style={{color: '#ffffff'}}></i>
            </a>
          </div>
        </div>

        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center opacity-20">
          <span className="font-orbitron text-[9px] tracking-[1em] mb-4">SCROLL</span>
          <div className="w-[1px] h-20 bg-gradient-to-b from-white to-transparent"></div>
        </div>
      </header>

      <main className="relative z-10">
        {/* Music Videos Section */}
        <section id="mv" className="max-w-7xl mx-auto px-6 py-40 space-y-72">
          {/* 01 紅蓮ノ閃光 */}
          <div className="reveal group">
            <div className="flex flex-col md:flex-row items-baseline mb-16 space-y-4 md:space-y-0 md:space-x-10">
              <h2 className="brand-logo text-5xl md:text-7xl text-red-800 border-l-4 border-red-800 pl-8">
                紅蓮ノ閃光
              </h2>
              <span className="font-orbitron text-gray-700 tracking-[0.5em] text-sm uppercase">
                Crimson Velocity
              </span>
            </div>
            <div className="relative">
              <div className="video-container rounded-sm overflow-hidden grayscale group-hover:grayscale-0 transition-all duration-1000">
                <iframe
                  src="https://www.youtube.com/embed/XIXAWrFZj8c?rel=0"
                  title="紅蓮ノ閃光 MV"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
            </div>
          </div>

          {/* 02 紅蓮ノ方舟 */}
          <div className="reveal group flex flex-col items-end">
            <div className="flex flex-col md:flex-row-reverse items-baseline mb-16 space-y-4 md:space-y-0 md:space-x-reverse md:space-x-10 text-right w-full">
              <h2 className="brand-logo text-5xl md:text-7xl text-red-800 border-r-4 border-red-800 pr-8">
                紅蓮ノ方舟
              </h2>
              <span className="font-orbitron text-gray-700 tracking-[0.5em] text-sm uppercase">
                Crimson Velocity Ⅱ
              </span>
            </div>
            <div className="relative w-full">
              <div className="video-container rounded-sm overflow-hidden grayscale group-hover:grayscale-0 transition-all duration-1000">
                <iframe
                  src="https://www.youtube.com/embed/Imo4yrxIrI8?rel=0"
                  title="紅蓮ノ方舟 MV"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
            </div>
          </div>
        </section>

        {/* Popular Tracks Section */}
        <section id="tracks" className="max-w-4xl mx-auto px-6 py-40">
          <div className="reveal">
            <h2 className="section-title">POPULAR TRACKS</h2>
            <div className="glass-morphism rounded-sm overflow-hidden border border-white/5 shadow-2xl">
              {/* Track 01 */}
              <a
                href="https://open.spotify.com/intl-ja/artist/2DzEGExZPV0OrSQbALBmwL"
                target="_blank"
                rel="noopener"
                className="track-item group"
              >
                <div className="flex items-center space-x-10 md:space-x-14">
                  <span className="track-number text-red-700 text-3xl md:text-4xl">01</span>
                  <div>
                    <h3 className="text-xl md:text-2xl font-bold tracking-widest group-hover:text-red-500 transition">
                      紅蓮ノ閃光 - Crimson Velocity -
                    </h3>
                    <p className="text-[10px] text-gray-500 mt-2 tracking-[0.1em] font-light italic">
                      4th Album "Noir Radiance"
                    </p>
                  </div>
                </div>
                <i className="fas fa-external-link-alt text-xs text-red-950 group-hover:text-red-600 transition duration-500"></i>
              </a>

              {/* Track 02 */}
              <a
                href="https://open.spotify.com/intl-ja/artist/2DzEGExZPV0OrSQbALBmwL"
                target="_blank"
                rel="noopener"
                className="track-item group"
              >
                <div className="flex items-center space-x-10 md:space-x-14">
                  <span className="track-number text-red-700 text-3xl md:text-4xl">02</span>
                  <div>
                    <h3 className="text-xl md:text-2xl font-bold tracking-widest group-hover:text-red-500 transition">
                      紅蓮ノ方舟 - Crimson VelocityⅡ -
                    </h3>
                    <p className="text-[10px] text-gray-500 mt-2 tracking-[0.1em] font-light italic">
                      4th Album "Noir Radiance"
                    </p>
                  </div>
                </div>
                <i className="fas fa-external-link-alt text-xs text-red-950 group-hover:text-red-600 transition duration-500"></i>
              </a>

              {/* Track 03 */}
              <a
                href="https://open.spotify.com/intl-ja/artist/2DzEGExZPV0OrSQbALBmwL"
                target="_blank"
                rel="noopener"
                className="track-item group"
              >
                <div className="flex items-center space-x-10 md:space-x-14">
                  <span className="track-number text-red-700 text-3xl md:text-4xl">03</span>
                  <div>
                    <h3 className="text-xl md:text-2xl font-bold tracking-widest group-hover:text-red-500 transition">
                      燈彩ノ現実 - Prism Reality -
                    </h3>
                    <p className="text-[10px] text-gray-500 mt-2 tracking-[0.1em] font-light italic">
                      4th Album "Noir Radiance"
                    </p>
                  </div>
                </div>
                <i className="fas fa-external-link-alt text-xs text-red-950 group-hover:text-red-600 transition duration-500"></i>
              </a>

              {/* Track 04 */}
              <a
                href="https://open.spotify.com/intl-ja/artist/2DzEGExZPV0OrSQbALBmwL"
                target="_blank"
                rel="noopener"
                className="track-item group"
              >
                <div className="flex items-center space-x-10 md:space-x-14">
                  <span className="track-number text-red-700 text-3xl md:text-4xl">04</span>
                  <div>
                    <h3 className="text-xl md:text-2xl font-bold tracking-widest group-hover:text-red-500 transition">
                      Shining Abyss
                    </h3>
                    <p className="text-[10px] text-gray-500 mt-2 tracking-[0.1em] font-light italic">
                      1st Album "Eternal Frame"
                    </p>
                  </div>
                </div>
                <i className="fas fa-external-link-alt text-xs text-red-950 group-hover:text-red-600 transition duration-500"></i>
              </a>

              {/* Track 05 */}
              <a
                href="https://open.spotify.com/intl-ja/artist/2DzEGExZPV0OrSQbALBmwL"
                target="_blank"
                rel="noopener"
                className="track-item group"
              >
                <div className="flex items-center space-x-10 md:space-x-14">
                  <span className="track-number text-red-700 text-3xl md:text-4xl">05</span>
                  <div>
                    <h3 className="text-xl md:text-2xl font-bold tracking-widest group-hover:text-red-500 transition uppercase">
                      Radiant Prayer
                    </h3>
                    <p className="text-[10px] text-gray-500 mt-2 tracking-[0.1em] font-light italic">
                      1st Album "Eternal Frame"
                    </p>
                  </div>
                </div>
                <i className="fas fa-external-link-alt text-xs text-red-950 group-hover:text-red-600 transition duration-500"></i>
              </a>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="bg-[#030303] py-56">
          <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-24 items-center">
            <div className="reveal order-2 md:order-1 space-y-16">
              <h2 className="section-title !text-left !m-0">ABOUT REiRA</h2>
              <div className="font-serif italic text-xl leading-relaxed text-white/60 space-y-10">
                <p className="reveal text-white font-bold text-2xl md:text-3xl">
                  AIから生まれた新時代のロックアーティスト
                </p>
                <p className="reveal">
                  人間の感情とAIの構造が交差する場所で、
                  <br />
                  ロックは再定義される。
                </p>
                <p className="reveal">
                  これは進化か、反逆か。
                  <br />
                  答えは音の中にある。
                </p>
              </div>
            </div>
            <div className="reveal order-1 md:order-2">
              <div className="relative p-6 border border-red-900/20 group">
                <img
                  src="/images/reira-profile.png"
                  alt="REiRA Profile Image"
                  className="w-full grayscale brightness-50 group-hover:grayscale-0 group-hover:brightness-100 transition duration-1000"
                />
                <div className="absolute -top-6 -left-6 w-24 h-24 border-t border-l border-red-800/50"></div>
                <div className="absolute -bottom-6 -right-6 w-24 h-24 border-b border-r border-red-800/50"></div>
              </div>
            </div>
          </div>
        </section>

        {/* Discography Section */}
        <section id="disc" className="max-w-7xl mx-auto px-6 py-40">
          <div className="reveal">
            <h2 className="section-title">DISCOGRAPHY</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 px-4 text-left">
              {/* Noir Radiance */}
              <a
                href="https://open.spotify.com/intl-ja/album/7Af68VTLCHE9KuRleFsMPh"
                target="_blank"
                rel="noopener"
                className="reveal group"
              >
                <div className="relative overflow-hidden mb-8 shadow-2xl border border-white/5 aspect-square">
                  <img
                    src="https://images.unsplash.com/photo-1493225255756-d9584f8606e9?q=80&w=1000&auto=format&fit=crop"
                    alt="Noir Radiance"
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition duration-1000"
                  />
                  <div className="absolute inset-0 bg-red-900/10 opacity-0 group-hover:opacity-100 transition"></div>
                </div>
                <h3 className="brand-logo text-xl md:text-2xl group-hover:text-red-600 transition">
                  Noir Radiance
                </h3>
                <p className="text-[10px] text-red-800 font-bold mt-2 tracking-[0.2em] uppercase">
                  4th Album / 2025.11.25
                </p>
              </a>

              {/* YOKU */}
              <a
                href="https://open.spotify.com/intl-ja/album/4yrTn6VMTHb3WQ1xkNz63D"
                target="_blank"
                rel="noopener"
                className="reveal group"
                style={{ transitionDelay: '100ms' }}
              >
                <div className="relative overflow-hidden mb-8 shadow-2xl border border-white/5 aspect-square">
                  <img
                    src="https://images.unsplash.com/photo-1493225255756-d9584f8606e9?q=80&w=1000&auto=format&fit=crop"
                    alt="YOKU"
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition duration-1000"
                  />
                </div>
                <h3 className="brand-logo text-xl md:text-2xl group-hover:text-red-600 transition">YOKU</h3>
                <p className="text-[10px] text-red-800 font-bold mt-2 tracking-[0.2em] uppercase">
                  3rd Album / 2025.10.03
                </p>
              </a>

              {/* Halloween Anthem */}
              <a
                href="https://open.spotify.com/intl-ja/album/7zkZ41BXVRut6ucIjbbR9M"
                target="_blank"
                rel="noopener"
                className="reveal group"
                style={{ transitionDelay: '200ms' }}
              >
                <div className="relative overflow-hidden mb-8 shadow-2xl border border-white/5 aspect-square">
                  <img
                    src="https://images.unsplash.com/photo-1509248961158-e54f6934749c?q=80&w=1000&auto=format&fit=crop"
                    alt="Halloween Anthem"
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition duration-1000"
                  />
                </div>
                <h3 className="brand-logo text-xl md:text-2xl group-hover:text-red-600 transition">
                  Halloween Anthem
                </h3>
                <p className="text-[10px] text-red-800 font-bold mt-2 tracking-[0.2em] uppercase">
                  2nd Album / 2025.10.10
                </p>
              </a>

              {/* Eternal Frame */}
              <a
                href="https://open.spotify.com/intl-ja/album/2a4rcDYmdgQGQeSNw1MBog"
                target="_blank"
                rel="noopener"
                className="reveal group"
                style={{ transitionDelay: '300ms' }}
              >
                <div className="relative overflow-hidden mb-8 shadow-2xl border border-white/5 aspect-square">
                  <img
                    src="https://images.unsplash.com/photo-1459749411177-042180ce673c?q=80&w=1000&auto=format&fit=crop"
                    alt="Eternal Frame"
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition duration-1000"
                  />
                </div>
                <h3 className="brand-logo text-xl md:text-2xl group-hover:text-red-600 transition">
                  Eternal Frame
                </h3>
                <p className="text-[10px] text-red-800 font-bold mt-2 tracking-[0.2em] uppercase">
                  1st Album / 2025.09.18
                </p>
              </a>
            </div>
          </div>
        </section>

        {/* Links Section */}
        <section id="links" className="py-56 border-t border-white/5 bg-black text-center">
          <h2 className="section-title !mb-20">LINKS</h2>
          <div className="reveal flex flex-wrap justify-center gap-20">
            <a
              href="https://www.tiktok.com/@reira_music"
              target="_blank"
              rel="noopener"
              className="group flex flex-col items-center"
            >
              <i className="fab fa-tiktok text-4xl text-white/10 group-hover:text-red-700 transition duration-700 mb-6"></i>
              <span className="font-orbitron text-[10px] tracking-[0.5em] opacity-0 group-hover:opacity-100 transition uppercase">
                TikTok
              </span>
            </a>
            <a
              href="https://www.youtube.com/@reira_music"
              target="_blank"
              rel="noopener"
              className="group flex flex-col items-center"
            >
              <i className="fab fa-youtube text-4xl text-white/10 group-hover:text-red-700 transition duration-700 mb-6"></i>
              <span className="font-orbitron text-[10px] tracking-[0.5em] opacity-0 group-hover:opacity-100 transition uppercase">
                YouTube
              </span>
            </a>
            <a
              href="https://open.spotify.com/intl-ja/artist/2DzEGExZPV0OrSQbALBmwL"
              target="_blank"
              rel="noopener"
              className="group flex flex-col items-center"
            >
              <i className="fab fa-spotify text-4xl text-white/10 group-hover:text-red-700 transition duration-700 mb-6"></i>
              <span className="font-orbitron text-[10px] tracking-[0.5em] opacity-0 group-hover:opacity-100 transition uppercase">
                Spotify
              </span>
            </a>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-24 text-center bg-black border-t border-white/5">
        <div className="text-3xl brand-logo text-red-950 mb-6">REiRA</div>
        <div className="font-orbitron text-[8px] text-white/10 tracking-[1em] mb-4 uppercase">
          Official Digital Archive
        </div>
        <p className="text-[8px] text-white/5 font-light">&copy; 2026 AI MUSIC ENTERTAINMENT.</p>
      </footer>
    </div>
  );
}
